const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const Incident = require('./models/Incident');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/ai_dashboard')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// API Routes
app.get('/api/incidents', async (req, res) => {
  const incidents = await Incident.find().sort({ reported_at: -1 });
  res.json(incidents);
});

app.post('/api/incidents', async (req, res) => {
  const { title, description, severity } = req.body;
  const incident = new Incident({ title, description, severity });
  await incident.save();
  res.status(201).json(incident);
});

// Serve static frontend from /public folder
app.use(express.static(path.join(__dirname, 'public')));

// Serve index.html for the root route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
