let incidents = [
    {
      id: 1,
      title: "Biased Recommendation Algorithm",
      description: "Algorithm consistently favored certain demographics...",
      severity: "Medium",
      reported_at: "2025-03-15T10:00:00Z",
      showDetails: false
    },
    {
      id: 2,
      title: "LLM Hallucination in Critical Info",
      description: "LLM provided incorrect safety procedure information...",
      severity: "High",
      reported_at: "2025-04-01T14:30:00Z",
      showDetails: false
    },
    {
      id: 3,
      title: "Minor Data Leak via Chatbot",
      description: "Chatbot inadvertently exposed non-sensitive user metadata...",
      severity: "Low",
      reported_at: "2025-03-20T09:15:00Z",
      showDetails: false
    }
  ];
  
  function renderIncidents() {
    const filter = document.getElementById("severityFilter").value;
    const sortOrder = document.getElementById("sortOrder").value;
    let filtered = [...incidents];
  
    if (filter !== "All") {
      filtered = filtered.filter(inc => inc.severity === filter);
    }
  
    filtered.sort((a, b) => {
      return sortOrder === "newest"
        ? new Date(b.reported_at) - new Date(a.reported_at)
        : new Date(a.reported_at) - new Date(b.reported_at);
    });
  
    const list = document.getElementById("incidentList");
    list.innerHTML = "";
  
    filtered.forEach(incident => {
      const item = document.createElement("li");
      item.className = "incident";
      item.innerHTML = `
        <strong>${incident.title}</strong><br>
        Severity: ${incident.severity}<br>
        Date: ${new Date(incident.reported_at).toLocaleString()}<br>
        <button onclick="toggleDetails(${incident.id})">
          ${incident.showDetails ? "Hide" : "View"} Details
        </button>
        <div class="details" style="display: ${incident.showDetails ? "block" : "none"};">
          <p>${incident.description}</p>
        </div>
      `;
      list.appendChild(item);
    });
  }
  
  function toggleDetails(id) {
    const incident = incidents.find(i => i.id === id);
    incident.showDetails = !incident.showDetails;
    renderIncidents();
  }
  
  document.getElementById("incidentForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const title = document.getElementById("title").value.trim();
    const description = document.getElementById("description").value.trim();
    const severity = document.getElementById("severity").value;
  
    if (!title || !description || !severity) {
      alert("Please fill all fields.");
      return;
    }
  
    incidents.push({
      id: incidents.length + 1,
      title,
      description,
      severity,
      reported_at: new Date().toISOString(),
      showDetails: false
    });
  
    this.reset();
    renderIncidents();
  });
  
  document.getElementById("severityFilter").addEventListener("change", renderIncidents);
  document.getElementById("sortOrder").addEventListener("change", renderIncidents);
  
  // Theme Toggle
  document.getElementById("themeToggle").addEventListener("click", () => {
    const body = document.body;
    const isLight = body.classList.contains("light");
    body.className = isLight ? "dark" : "light";
    document.getElementById("themeToggle").textContent = isLight ? "☀️ Light Mode" : "🌙 Dark Mode";
  });
  
  // Initial Render
  renderIncidents();
  